﻿namespace TaskPlanning.JobAssignment.Simulation
{
    public enum OperationState
    {
        NotReady,
        Ready,
        Started,
        Finished
    }
}
