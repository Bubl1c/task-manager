﻿using GraphLogic.Entities;
using TaskPlanning.Statistics;

using System.Collections.Generic;

namespace TaskPlanning.Queueing
{
    public interface IQueueingAlgorithm
    {
        string Name { get; }
        string Description { get; }

        OperationQueue Compute(IEnumerable<Operation> task, TaskGraphStat statistics);
    }
}
