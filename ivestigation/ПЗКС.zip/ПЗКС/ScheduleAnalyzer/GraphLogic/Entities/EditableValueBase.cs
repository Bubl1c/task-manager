﻿using System.ComponentModel;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace GraphLogic.Entities
{
    public abstract class EditableValueBase : INotifyPropertyChanged, IDeepClonable<EditableValueBase>, IXmlSerializable
    {
        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        protected void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        public int ID { get; protected set; }

        public EditableValueBase(int id)
        {
            ID = id;
        }

        IDeepClonable IDeepClonable.DeepCopy()
        {
            return DeepCopy();
        }

        public virtual EditableValueBase DeepCopy()
        {
            return MemberwiseClone() as EditableValueBase;
        }
    
        public abstract XmlSchema GetSchema();

        public abstract void ReadXml(XmlReader reader);

        public abstract void WriteXml(XmlWriter writer);
    }
}
