﻿namespace GraphLogic.Entities
{
    public interface IUniqueObject
    {
        int ID { get; }
    }
}
