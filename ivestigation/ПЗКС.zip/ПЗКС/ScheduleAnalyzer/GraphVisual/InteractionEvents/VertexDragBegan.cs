﻿using Microsoft.Practices.Prism.PubSubEvents;
using GraphVisual.Controls;

namespace GraphVisual.InteractionEvents
{
    class VertexEditBegan : PubSubEvent<VertexControl> { }
}
