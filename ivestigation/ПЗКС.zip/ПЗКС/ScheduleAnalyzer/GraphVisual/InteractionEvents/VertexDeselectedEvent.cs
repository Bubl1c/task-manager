﻿using Microsoft.Practices.Prism.PubSubEvents;
using GraphVisual.Controls;

namespace GraphVisual.InteractionEvents
{
    class VertexDeselectedEvent : PubSubEvent<VertexControl> { }
}
