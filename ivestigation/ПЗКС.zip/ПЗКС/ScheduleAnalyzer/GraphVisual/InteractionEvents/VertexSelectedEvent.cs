﻿using Microsoft.Practices.Prism.PubSubEvents;
using GraphVisual.Controls;

namespace GraphVisual.InteractionEvents
{
    class VertexSelectedEvent : PubSubEvent<VertexControl> { }
}
