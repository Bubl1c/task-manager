﻿using Microsoft.Practices.Prism.Mvvm;
using GraphVisual.Controls;

using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using UI.Helpers;
using MainApp.ViewModels;
using GraphLogic.Entities;
using TaskPlanning.JobAssignment;

namespace MainApp.Views
{
    public partial class MainWindow : Window, IView
    {
        private PathInfoFloatingWindow pathInfoWindow = new PathInfoFloatingWindow();
        private QueueingFloatingWindow queueWindow = new QueueingFloatingWindow();
        
        public MainWindow()
        {
            InitializeComponent();
            Loaded += delegate
            {
                pathInfoWindow.Owner = this;
                queueWindow.Owner = this;
            };
        }
        
        private void ShowFloating(Window window, object dataContext)
        {
            window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            window.DataContext = dataContext;
            window.Show();
        }

        private void AssignJobsButton_Click(object sender, RoutedEventArgs e)
        {
            var vm = this.DataContext as MainWindowViewModel;
            var options = new PcsOptions(vm.ProcessorGraph.Vertices.Cast<Processor>());

            var dialog = new JobAssignmentDialog
            {
                Owner = this,
                DataContext = options
            };
            
            if (dialog.ShowDialog() == true && vm.CanAssignJobs())
            {
                vm.PcsInfo = options;
                vm.AssignJobs();

                var window = new GanntChartWindow(options, vm.Schedule)
                {
                    Owner = this,
                    DataContext = this.DataContext
                };
                window.Show();
            }
        }

        private void GenerateTaskGraphButton_Click(object sender, RoutedEventArgs e)
        {
            var vm = this.DataContext as MainWindowViewModel;
            var taskGenerationInfo = new TaskGenerationInfo();

            var dialog = new TaskGenerationDialog
            {
                Owner = this,
                DataContext = taskGenerationInfo
            };

            if (dialog.ShowDialog() == true)
            {
                vm.GenerateTaskGraph(taskGenerationInfo);
            }            
        }

        private void MakeQueueButton_Click(object sender, RoutedEventArgs e)
        {
            if (MakeQueueButton.Command != null && MakeQueueButton.Command.CanExecute(null))
            {
                MakeQueueButton.Command.Execute(MakeQueueButton.CommandParameter);

                ShowFloating(pathInfoWindow, (DataContext as dynamic).PathInfo);
                ShowFloating(queueWindow, (DataContext as dynamic).PlanningQueue);

                if (ActualWidth < CurrentScreen.Width)
                {
                    this.PlaceFloatingWindow(pathInfoWindow, new PlaceInfo { AttachTo = AttachPosition.Left, OutsideHorizontal = true });
                    this.PlaceFloatingWindow(queueWindow, new PlaceInfo { AttachTo = AttachPosition.Right, OutsideHorizontal = true });
                }
                else
                {
                    this.PlaceFloatingWindow(pathInfoWindow, new PlaceInfo { AttachTo = AttachPosition.Left, SkipParentBorder = true, OffsetX = 5 });
                    this.PlaceFloatingWindow(queueWindow, new PlaceInfo { AttachTo = AttachPosition.Right, SkipParentBorder = true, OffsetX = -5 });
                }
            }
        }

        private void Self_Loaded(object sender, RoutedEventArgs e)
        {
            //var model = DataContext as MainWindowViewModel;
            
            //PcsEditor.LoadGraph("..\\..\\..\\TestGraphs\\pcs.peg");
            //TaskEditor.LoadGraph("..\\..\\..\\TestGraphs\\task.tag");

            //MakeQueueButton_Click(null, null);
            //AssignJobsButton_Click(null, null);
        }
    }
}
