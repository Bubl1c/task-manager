﻿using Microsoft.Practices.Prism.Mvvm;

namespace MainApp.ViewModels
{
    public class TaskGenerationInfo : BindableBase 
    {
        private int operationCount;

        private int minComplexity;
        private int maxComplexity;
        
        private double connectivity;

        public int OperationCount
        {
            get
            {
                return operationCount;
            }
            set
            {
                operationCount = value;
                OnPropertyChanged("OperationCount");
            }
        }

        public int MinComplexity
        {
            get
            {
                return minComplexity;
            }
            set
            {
                minComplexity = value;
                OnPropertyChanged("MinComplexity");
            }
        }

        public int MaxComplexity
        {
            get
            {
                return maxComplexity;
            }
            set
            {
                maxComplexity = value;
                OnPropertyChanged("MaxComplexity");
            }
        }

        public double Connectivity
        {
            get
            {
                return connectivity;
            }
            set
            {
                connectivity = value;
                OnPropertyChanged("Connectivity");
            }
        }

        public TaskGenerationInfo()
        {
            OperationCount = 6;

            MinComplexity = 1;
            MaxComplexity = 7;

            Connectivity = 0.8;
        }
    }
}
