﻿using GraphLogic.Entities;
using GraphLogic.Graphs;

using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Interactivity.InteractionRequest;
using Microsoft.Practices.Prism.Mvvm;
using Microsoft.Practices.Prism.PubSubEvents;

using QuickGraph;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

using TaskPlanning.Queueing;
using TaskPlanning.JobAssignment;
using TaskPlanning.JobAssignment.Algorithms;
using TaskPlanning.Statistics;

namespace MainApp.ViewModels
{
    class MainWindowViewModel : BindableBase
    {
        private static readonly IQueueingAlgorithm[] queueingAlgorithms;
        private static readonly JobAssignmentAlgorithm[] jobAssignmentAlgorithms;

        private static T[] CreateAllSubClassInstances<T>()
        {
            var baseType = typeof(T);
            return AppDomain.CurrentDomain.GetAssemblies()
                                          .SelectMany(ass => ass.GetTypes())
                                          .Where(qa => qa.IsClass && baseType.IsAssignableFrom(qa) &&
                                                          qa.GetConstructor(Type.EmptyTypes) != null)
                                          .Select(type => Activator.CreateInstance(type))
                                          .OfType<T>()
                                          .ToArray();
        }

        static MainWindowViewModel()
        {
            queueingAlgorithms = CreateAllSubClassInstances<IQueueingAlgorithm>();
            jobAssignmentAlgorithms = CreateAllSubClassInstances<JobAssignmentAlgorithm>();
        }

        #region Binding properties

        private Processor[] processors;
        private Schedule schedule;
        private PcsOptions pcsInfo;

        private TaskGraphStat pathInfo;
        private OperationQueue planningQueue;

        private IQueueingAlgorithm selectedQueueingAlgorithm;
        private JobAssignmentAlgorithm selectedJobAssignmentAlgorithm;

        private UndirectedWeightedGraph processorGraph;
        private DirectedWeightedGraph taskGraph;

        public PcsOptions PcsInfo
        {
            get
            {
                return pcsInfo;
            }
            set
            {
                pcsInfo = value;
                OnPropertyChanged("PcsInfo");
            }
        }

        public Schedule Schedule
        {
            get
            {
                return schedule;
            }
            set
            {
                schedule = value;
                OnPropertyChanged("Schedule");
            }
        }

        public IQueueingAlgorithm[] QueueingAlgorithms
        {
            get { return queueingAlgorithms; }
        }

        public JobAssignmentAlgorithm[] JobAssignmentAlgorithms
        {
            get { return jobAssignmentAlgorithms; }
        }

        public IQueueingAlgorithm SelectedQueueingAlgorithm
        {
            get
            {
                return selectedQueueingAlgorithm;
            }
            set
            {
                selectedQueueingAlgorithm = value;
                OnPropertyChanged("SelectedQueueingAlgorithm");

                MakeQueueCommand.RaiseCanExecuteChanged();
            }
        }

        public JobAssignmentAlgorithm SelectedJobAssignmentAlgorithm
        {
            get
            {
                return selectedJobAssignmentAlgorithm;
            }
            set
            {
                selectedJobAssignmentAlgorithm = value;
                OnPropertyChanged("SelectedJobAssignmentAlgorithm");

                AssignJobsCommand.RaiseCanExecuteChanged();
            }
        }

        public TaskGraphStat PathInfo
        {
            get
            {
                return pathInfo;
            }
            set
            {
                pathInfo = value;
                OnPropertyChanged("PathInfo");
            }
        }

        public OperationQueue PlanningQueue
        {
            get
            {
                return planningQueue;
            }
            set
            {
                planningQueue = value;
                OnPropertyChanged("PlanningQueue");

                AssignJobsCommand.RaiseCanExecuteChanged();
            }
        }

        public UndirectedWeightedGraph ProcessorGraph
        {
            get
            {
                return processorGraph;
            }
            set
            {
                processorGraph = value;
                OnPropertyChanged("ProcessorGraph");

                AssignJobsCommand.RaiseCanExecuteChanged();
            }
        }

        public DirectedWeightedGraph TaskGraph
        {
            get
            {
                return taskGraph;
            }
            set
            {
                taskGraph = value;
                OnPropertyChanged("TaskGraph");
                
                MakeQueueCommand.RaiseCanExecuteChanged();
                AssignJobsCommand.RaiseCanExecuteChanged();
            }
        }

        #endregion

        #region Interaction requests & commands

        public DelegateCommand MakeQueueCommand { get; private set; }
        public DelegateCommand AssignJobsCommand { get; private set; }
        public DelegateCommand GenerateTaskCommand { get; private set; }

        public InteractionRequest<Confirmation> ShowDialogRequest { get; private set; }
        public InteractionRequest<Confirmation> ShowFloatingWindowRequest { get; private set; }

        #endregion

        public MainWindowViewModel()
        {
            ShowDialogRequest = new InteractionRequest<Confirmation>();
            ShowFloatingWindowRequest = new InteractionRequest<Confirmation>();

            //GenerateTaskCommand = new DelegateCommand(ShowGraphGenerationDialog);
            AssignJobsCommand = new DelegateCommand(AssignJobs, CanAssignJobs);
            MakeQueueCommand = new DelegateCommand(MakeQueue, CanMakeQueue);

            ProcessorGraph = new UndirectedWeightedGraph();
            TaskGraph = new DirectedWeightedGraph();
        }

        public bool CanAssignJobs()
        {
            return !(TaskGraph == null ||
                     PlanningQueue == null ||
                     ProcessorGraph == null ||
                     SelectedJobAssignmentAlgorithm == null);
        }

        public void AssignJobs()
        {
            var algo = SelectedJobAssignmentAlgorithm;
            algo.Initialize(ProcessorGraph, TaskGraph, PlanningQueue);
            Schedule = algo.Compute(PcsInfo);
        }

        private bool CanMakeQueue()
        {
            return !(TaskGraph == null ||
                     SelectedQueueingAlgorithm == null);                     
        }

        public void MakeQueue()
        {
            if (SelectedQueueingAlgorithm != null && !TaskGraph.IsVerticesEmpty)
            {
                PathInfo = TaskGraphStat.Gather(TaskGraph);
                PlanningQueue = SelectedQueueingAlgorithm.Compute(TaskGraph.Vertices.Cast<Operation>(), PathInfo);
            }
        }

        public void GenerateTaskGraph(TaskGenerationInfo info)
        {
            var newGraph = new DirectedWeightedGraph();

            var rand = new Random(Environment.TickCount);
            var vertices = new List<Operation>();

            for (int v = 1; v <= info.OperationCount; v++)
            {
                var vertex = new Operation(v)
                {
                    Type = OperationType.Function,
                    Complexity = rand.Next(info.MinComplexity, info.MaxComplexity + 1)
                };

                vertices.Add(vertex);
                newGraph.AddVertex(vertex);
            }

            var totalVertexComplexity = vertices.Sum(v => v.Complexity);
            var totalEdgeWeight = (int)(totalVertexComplexity / info.Connectivity - totalVertexComplexity);

            var minEdgeWeight = 1;
            var maxEdgeWeight = (int)Math.Ceiling(totalEdgeWeight / 4.0);

            var edges = new List<Tuple<int, int>>();

            while (totalEdgeWeight >= minEdgeWeight)
            {
                var number = rand.Next(info.OperationCount * info.OperationCount);
                var start = number / info.OperationCount;
                var end = number % info.OperationCount;
                var edge = new Tuple<int, int>(start, end);

                if (start != end && !edges.Contains(edge))
                {
                    var weight = rand.Next(minEdgeWeight, maxEdgeWeight + 1);
                    if (weight > totalEdgeWeight)
                        weight = totalEdgeWeight;
                    
                    var weightedEdge = new WeightedEdge(vertices[start], vertices[end], weight);
                    newGraph.AddEdge(weightedEdge);

                    if (newGraph.IsAcyclic)
                    {
                        edges.Add(edge);
                        totalEdgeWeight -= weight;
                    }
                    else
                    {
                        newGraph.RemoveEdge(weightedEdge);
                    }
                }
            }
            TaskGraph = newGraph;
        }
    }
}
